<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Marca de vehículo</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-md-6">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th></th>
                        <th>Descripción</th>
                        <th>Logo</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a class="mvEditar" title="Editar" href="#" data-id="<?php echo e($registro->id); ?>" data-descripcion="<?php echo e($registro->descripcion); ?>"><i class="fa fa-pencil fa-lg" aria-hidden="true"></i></a>
                        </td>
                        <td><?php echo e($registro->descripcion); ?></td>
                        <td>
                            <?php if($registro->logo != ''): ?>
                            <img src="uploads/marca-vehiculo/<?php echo e($registro->logo); ?>" alt="Logo <?php echo e($registro->descripcion); ?>" class="img-responsive center-block" style="max-width:132px">
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2"><p class="">No se encontraron registros</p></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <h4 id="tituloMv">Crear marca de vehículo</h4>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('vmar_agregar')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="0" id="mv_id">
                <div class="form-group">
                    <input type="text" class="form-control" name="descripcion" id="mv_descripcion" placeholder="*Descripción" maxlength="100" required autofocus>
                </div>
                <div class="form-group">
                    <label for="logo">Logo</label>
                    <input type="file" name="logo" id="logo" accept="image/*">
                </div>
                <input type="submit" value="Guardar" class="btn btn-primary pull-right" style="margin-left:12px">
                <input type="button" value="Cancelar" class="btn btn-default pull-right" id="mvCancelar" style="display:none">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(function(){
        $('.mvEditar').click(function() {
            var boton = $(this);
            var msg = 'Editar marca de vehículo <small>'+boton.data('descripcion')+'</small>';
            $('#mv_id').val(boton.data('id'));
            $('#mv_descripcion').val(boton.data('descripcion')).focus();
            $('#tituloMv').html(msg);
            $('#mvCancelar').toggle('slow');
            return false;
        });
        $('#tvCancelar').click(function() {
        	var msg = 'Crear marca de vehículo';
            $('#mv_id').val(0);
            $('#mv_descripcion').val('').focus();
            $('#tituloMv').html(msg);
            $(this).toggle('slow');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>