<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Tipo de vehículo</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-md-6">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th></th>
                        <th>Descripción</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a class="tvEditar" title="Editar" href="#" data-id="<?php echo e($registro->id); ?>" data-descripcion="<?php echo e($registro->descripcion); ?>"><i class="fa fa-pencil fa-lg" aria-hidden="true"></i></a>
                        </td>
                        <td><?php echo e($registro->descripcion); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2"><p class="">No se encontraron registros</p></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <h4 id="tituloTv">Crear tipo de vehículo</h4>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('tv_agregar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="0" id="tv_id">
                <div class="form-group">
                    <input type="text" class="form-control" name="descripcion" id="tv_descripcion" placeholder="*Descripción" maxlength="100" required autofocus>
                </div>
                <input type="submit" value="Guardar" class="btn btn-primary pull-right" style="margin-left:12px">
                <input type="button" value="Cancelar" class="btn btn-default pull-right" id="tvCancelar" style="display:none">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(function(){
        $('.tvEditar').click(function() {
            var boton = $(this);
            var msg = 'Editar tipo de vehículo <small>'+boton.data('descripcion')+'</small>';
            $('#tv_id').val(boton.data('id'));
            $('#tv_descripcion').val(boton.data('descripcion')).focus();
            $('#tituloTv').html(msg);
            $('#tvCancelar').toggle('slow');
            return false;
        });
        $('#tvCancelar').click(function() {
        	var msg = 'Crear tipo de vehículo';
            $('#tv_id').val(0);
            $('#tv_descripcion').val('').focus();
            $('#tituloTv').html(msg);
            $(this).toggle('slow');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>