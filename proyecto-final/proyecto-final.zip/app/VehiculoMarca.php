<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehiculoMarca extends Model
{
    protected $table = 'vehiculo_marca';
}
