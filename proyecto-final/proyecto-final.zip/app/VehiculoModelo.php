<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehiculoModelo extends Model
{
    protected $table = 'vehiculo_modelo';
}
